# fxserver-esx_skin
FXServer ESX Skin

[REQUIREMENTS]

- skinchanger => https://github.com/FXServer-ESX/fxserver-skinchanger

[INSTALLATION]

1) CD in your resources/[esx] folder
2) Clone the repository
```
git clone https://github.com/FXServer-ESX/fxserver-esx_skin esx_skin
```
3) Add this in your server.cfg :

```
start esx_skin
```
