Locales['fi'] = {
  ['new_job'] = 'Sinulla on nyt uusi työ !',
  ['access_job_center'] = 'paina ~INPUT_PICKUP~ vaihtaaksesi työtä ~b~työkeskuksessa~s~.',
  ['job_center'] = 'työkeskus',
}
