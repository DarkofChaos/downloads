Locales['sv'] = {
  ['new_job'] = 'du har ett nytt jobb! ~y~Tips:~s~ kolla kartan för nya blips.',
  ['access_job_center'] = 'tryck ~INPUT_PICKUP~ för att öppna ~b~arbetsförmedlingen~s~',
  ['job_center'] = 'arbetsförmedlingen',
}
