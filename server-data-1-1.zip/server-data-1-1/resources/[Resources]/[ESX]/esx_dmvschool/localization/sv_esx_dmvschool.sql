USE `essentialmode`;

INSERT INTO `licenses` (`type`, `label`) VALUES
	('dmv', 'Körkortstillstånd'),
	('drive', 'B-körkort'),
	('drive_bike', 'A-körkort'),
	('drive_truck', 'C-körkort')
;
