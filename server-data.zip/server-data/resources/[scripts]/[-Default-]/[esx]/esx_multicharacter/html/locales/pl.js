const translate = new Object();

translate.name = "imię";
translate.job = "Zajęcie";
translate.bank = "Bank";
translate.money = "Gotówka";
translate.gender = "Seks";
translate.dob = "Data urodzenia";
