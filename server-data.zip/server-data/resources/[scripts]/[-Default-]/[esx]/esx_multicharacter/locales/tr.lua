Locales['tr'] = {
	['male'] = "Erkek",
	['female'] = "Kadın",
	['delete_label'] = "Sil %s %s?",
	['select_char'] = "Karakter Seç",
	['create_char'] = "Yeni Karakter Oluştur",
	['char_play'] = "Bu Karakterle Oyna",
	['char_delete'] = "Bu Karakteri Sil",
	['cancel'] = "İptal",
	['confirm'] = "Onayla",
}
