Config = {}
Config.Locale = 'en'
