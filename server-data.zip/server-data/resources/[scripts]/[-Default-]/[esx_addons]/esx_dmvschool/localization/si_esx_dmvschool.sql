USE `es_extended`;

INSERT INTO `licenses` (`type`, `label`) VALUES
	('dmv', 'CPP Licenca'),
	('drive', 'Licenca za voznjo avtomobila'),
	('drive_bike', 'Licenca za voznjo motorja'),
	('drive_truck', 'Licenca za voznjo tovornjaka')
;
