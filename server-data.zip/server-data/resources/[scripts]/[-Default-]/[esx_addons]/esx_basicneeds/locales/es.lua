Locales['es'] = {
  ['used_bread'] = 'Has usado 1x pan',
  ['used_water'] = 'Has usado 1x agua',
}