Locales['de'] = {
  ['used_bread'] = 'du hast 1x Brot gegessen',
  ['used_water'] = 'du hast 1x Wasser getrunken',
}