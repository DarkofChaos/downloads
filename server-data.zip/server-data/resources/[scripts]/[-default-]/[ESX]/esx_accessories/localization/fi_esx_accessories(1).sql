USE `essentialmode`;

INSERT INTO `datastore` (name, label, shared) VALUES
	('user_ears', 'Örontilbb', 0),
	('user_glasses', 'Lasit', 0),
	('user_helmet', 'Kypärät', 0),
	('user_mask', 'Maskit', 0)
;
