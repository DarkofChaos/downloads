Locales['cs'] = {
  ['show_registration'] = 'zobrazit registracni menu',
  ['show_active_character'] = 'zobrazit aktivni postavy',
  ['delete_character'] = 'smazat svou stavajici postavu a vytvorit novou',
  ['deleted_character'] = 'vase postava byla smazana.',
  ['not_registered'] = 'nemas zaregistrovanou postavu.',
  ['active_character'] = 'aktivni postava: %s %s',
  ['already_registered'] = 'jiz mas zaregistrovanou postavu.',
  ['failed_identity'] = 'nastaveni vasi postavy selhalo, zkus to prosim znovu pozdeji nebo kontaktuj majitele serveru!',
  ['create_a_character'] = 'aby jsi mohl/a hrat, tak se musis registrovat.'
}
