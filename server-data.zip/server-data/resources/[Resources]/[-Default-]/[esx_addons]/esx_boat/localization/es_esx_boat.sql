USE `es_extended`;

INSERT INTO `licenses` (`type`, `label`) VALUES
    ('boat', 'Licencia de Barcos')
;
