Locales['en'] = {
  ['invalid_amount'] = 'That\'s an invalid amount of money',
  ['deposit_money']  = 'you have deposited $%s',
  ['withdraw_money'] = 'you have withdrawn $%s',
  ['press_e_banking']    = 'press [E] to access the bank',
  ['banking_blip']       = 'Bank',
}
