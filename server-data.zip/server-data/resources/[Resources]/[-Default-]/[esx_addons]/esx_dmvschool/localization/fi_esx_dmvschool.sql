USE `es_extended`;

INSERT INTO `licenses` (`type`, `label`) VALUES
	('dmv', 'Teoriakoe'),
	('drive', 'Autokortti'),
	('drive_bike', 'Moottoripyöräkortti'),
	('drive_truck', 'Rekkakortti')
;
