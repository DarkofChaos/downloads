Locales['hu'] = {
  ['used_bread'] = 'Megettél egy 1x kenyeret.',
  ['used_water'] = 'Megittál egy 1x vizet.',
}