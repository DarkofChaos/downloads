Locales['en'] = {
  ['used_bread'] = 'you have used 1x bread',
  ['used_water'] = 'you have used 1x water',
}