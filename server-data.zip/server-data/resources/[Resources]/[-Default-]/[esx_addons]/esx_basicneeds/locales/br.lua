Locales['br'] = {
  ['used_bread'] = 'você comeu 1x pão',
  ['used_water'] = 'você tomou 1x água',
}