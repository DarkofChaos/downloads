Locales['fr'] = {
  ['used_bread'] = 'vous avez utilisé 1x pain',
  ['used_water'] = 'vous avez utilisé 1x eau',
}