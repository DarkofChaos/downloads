Locales['si'] = {
  ['invoices'] = 'racuni',
  ['invoices_item'] = '$%s',
  ['received_invoice'] = 'pravkar ste prejeli račun',
  ['paid_invoice'] = 'plačali ste račun v višini ~r~$%s',
  ['no_invoices'] = 'v tem trenutku nimate računov za plačilo',
  ['received_payment'] = 'prejeli ste plačilo v višini ~r~$%s',
  ['player_not_online'] = 'igralec ni prijavljen',
  ['no_money'] = 'nimate dovolj denarja za plačilo tega računa',
  ['target_no_money'] = 'igralec ~r~does not ima dovolj denarja za plačilo računa!',
  ['keymap_showbills'] = 'odpre meni z računi',
}