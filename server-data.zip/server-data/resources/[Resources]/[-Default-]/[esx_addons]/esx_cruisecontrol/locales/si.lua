Locales['en'] = {
  ['activated']   = 'Aktivirano',
  ['deactivated'] = 'Deaktivirano',
}
