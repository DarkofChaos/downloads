Locales['fi'] = {
  ['activated']   = 'aktivoitu',
  ['deactivated'] = 'sammutettu',
}
