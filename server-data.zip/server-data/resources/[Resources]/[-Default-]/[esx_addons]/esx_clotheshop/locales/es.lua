Locales['es'] = {
  ['valid_this_purchase'] = '¿Validar esta compra?',
  ['yes'] = 'Si',
  ['no'] = 'No',
  ['not_enough_money'] = 'No tienes suficiente dinero',
  ['press_menu'] = 'Presiona [E] para acceder al menú',
  ['clothes'] = 'Ropa',
  ['you_paid'] = 'Has pagado €%s',
  ['save_in_dressing'] = '¿Quieres darle un nombre a tu vestuario?',
  ['name_outfit'] = 'nombre del traje?',
  ['saved_outfit'] = 'the outfit has been saved!',
}